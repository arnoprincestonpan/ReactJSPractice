export const assignmentColumn = [
    {
        Header: 'Lesson',
        accessor: 'lesson'
    },
    {
        Header: 'Assignment',
        accessor: 'assignment'
    },
    {
        Header: 'Marked(Y/N)',
        accessor: 'marked'
    },
    {
        Header: 'Grade',
        accessor: 'grade'
    }
]