import React from 'react'

function Reason() {
  return (
    <div>
        <h1>Reason for Taking COMP 1850</h1>
        <p>
        After being laid off from my construction estimator job after COVID-19, I have realized the scalability of my job is limited. 
        In the time off, I wanted to enter the September 2020 to May 2021 Software Systems Developer program. 
        I didn't know we could reserve a seat before entering the program. 
        So, I didn't send in an application form until I finished my COMP 1409 course. By then the program was full. 
        Instead of sitting around, I have decided to take as many Part-Time Courses as possible in the CST Program. 
        Web Programming, being my eventual goal, COMP 1850 is a for sure course from BCIT. 
        It's been over a decade since I have touched html. So I only remember the basic mark-ups. 
        Other than that, I remember creating a drop down menu. 
        I hope I will slowly be able to pick things up and be confident that I will go through course swiftly 
        and learn new things that will shape my possible career in web programming.
        </p>
    </div>
  )
}

export default Reason