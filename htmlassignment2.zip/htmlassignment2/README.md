# Redoing HTML & CSS Assignment #2 via React.js

## To Start
Make sure you add the npm packages by "npm install"

## Purpose
To re-create old assignments using React.js, this way there is a practice of HTML, CSS, JavaScript and React.js

### What is used in this?
- React.js
- React-Table