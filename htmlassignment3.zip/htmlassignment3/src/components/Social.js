import React from 'react'

function Social() {
  return (
    <footer>
      <nav>
        <p>Add Me (Arno Princeston Pan) on <a href="https://www.linkedin.com/in/arno-pan-064702b9/">LinkedIn</a></p>
        <p>BCIT CST 2022 Graduate</p>
      </nav>
    </footer>
  )
}

export default Social